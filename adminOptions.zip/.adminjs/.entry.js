AdminJS.UserComponents = {}
import Component1 from '../node_modules/@adminjs/upload/src/features/upload-file/components/edit'
AdminJS.UserComponents.Component1 = Component1
import Component2 from '../node_modules/@adminjs/upload/src/features/upload-file/components/list'
AdminJS.UserComponents.Component2 = Component2
import Component3 from '../node_modules/@adminjs/upload/src/features/upload-file/components/show'
AdminJS.UserComponents.Component3 = Component3
import Component4 from '../node_modules/@adminjs/upload/src/features/upload-file/components/edit'
AdminJS.UserComponents.Component4 = Component4
import Component5 from '../node_modules/@adminjs/upload/src/features/upload-file/components/list'
AdminJS.UserComponents.Component5 = Component5
import Component6 from '../node_modules/@adminjs/upload/src/features/upload-file/components/show'
AdminJS.UserComponents.Component6 = Component6
import Component7 from '../node_modules/@adminjs/upload/src/features/upload-file/components/edit'
AdminJS.UserComponents.Component7 = Component7
import Component8 from '../node_modules/@adminjs/upload/src/features/upload-file/components/list'
AdminJS.UserComponents.Component8 = Component8
import Component9 from '../node_modules/@adminjs/upload/src/features/upload-file/components/show'
AdminJS.UserComponents.Component9 = Component9
import Component10 from '../adminOptions/components/imageAdd'
AdminJS.UserComponents.Component10 = Component10